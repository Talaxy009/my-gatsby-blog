var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/tweet.ts
var tweet_exports = {};
__export(tweet_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(tweet_exports);

// node_modules/react-tweet/dist/api/get-tweet.js
var SYNDICATION_URL = "https://cdn.syndication.twimg.com";
var TwitterApiError = class extends Error {
  constructor({ message, status, data }) {
    super(message);
    this.name = "TwitterApiError";
    this.status = status;
    this.data = data;
  }
};
var TWEET_ID = /^[0-9]+$/;
async function getTweet(id) {
  var _res_headers_get;
  if (id.length > 40 || !TWEET_ID.test(id)) {
    throw new Error(`Invalid tweet id: ${id}`);
  }
  const url = new URL(`${SYNDICATION_URL}/tweet-result`);
  url.searchParams.set("id", id);
  url.searchParams.set("lang", "en");
  url.searchParams.set("features", [
    "tfw_timeline_list:",
    "tfw_follower_count_sunset:true",
    "tfw_tweet_edit_backend:on",
    "tfw_refsrc_session:on",
    "tfw_show_business_verified_badge:on",
    "tfw_duplicate_scribes_to_settings:on",
    "tfw_show_blue_verified_badge:on",
    "tfw_legacy_timeline_sunset:true",
    "tfw_show_gov_verified_badge:on",
    "tfw_show_business_affiliate_badge:on",
    "tfw_tweet_edit_frontend:on"
  ].join(";"));
  const res = await fetch(url.toString());
  const isJson = (_res_headers_get = res.headers.get("content-type")) == null ? void 0 : _res_headers_get.includes("application/json");
  const data = isJson ? await res.json() : void 0;
  if (res.ok)
    return data;
  if (res.status === 404)
    return;
  throw new TwitterApiError({
    message: typeof data.error === "string" ? data.error : "Bad request.",
    status: res.status,
    data
  });
}

// netlify/functions/tweet.ts
var headers = {
  "Access-Control-Allow-Origin": "http://localhost:8000"
};
var handler = async (event, _context) => {
  const tweetId = event.path.split("/").pop();
  console.log({ tweetId });
  if (event.httpMethod !== "GET" || typeof tweetId !== "string") {
    return {
      headers,
      statusCode: 400,
      body: JSON.stringify({ error: "Bad Request." })
    };
  }
  try {
    const tweet = await getTweet(tweetId);
    return {
      headers,
      statusCode: tweet ? 200 : 404,
      body: JSON.stringify({ data: tweet ?? null })
    };
  } catch (error) {
    console.error(error);
    return {
      headers,
      statusCode: 400,
      body: JSON.stringify({ error: error.message ?? "Bad request." })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
